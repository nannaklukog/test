import os
from cryptography.fernet import Fernet

def decrypt_file(path, key, custom_ext):
    f = Fernet(key)
    with open(path, "rb") as file:
        encrypted_data = file.read()
    decrypted_data = f.decrypt(encrypted_data)
    orig_path = path[:-len(custom_ext)]
    with open(orig_path, "wb") as file:
        file.write(decrypted_data)
    os.remove(path)

def main():
    root_path = os.path.join(os.getenv('USERPROFILE'), "Documents")
    key_path = os.path.join(os.getenv('USERPROFILE'), "Downloads")
    custom_ext = ".bak"
    key_file_path = os.path.join(key_path, "filekey.bin")
    with open(key_file_path, "rb") as key_file:
        key = key_file.read()

    files_to_decrypt = []
    for folder, _, files in os.walk(root_path):
        for file in files:
            full_path = os.path.join(folder, file)
            if full_path.endswith(custom_ext):
                files_to_decrypt.append(full_path)

    for filename in files_to_decrypt:
        try:
            decrypt_file(filename, key, custom_ext)
        except Exception as e:
            print(f"Failed to decrypt {filename}: {e}")

if __name__ == "__main__":
    main()
